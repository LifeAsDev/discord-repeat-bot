import DeckCreator from "./deckClass.js"

function sendDeckToRuntime(runtime) {
    const sections = Object.keys(runtime.lifeAsDev.DeckCreator.deck);

    for (const sec of sections) {
        const entries = Object.entries(runtime.lifeAsDev.DeckCreator.deck[sec]); // [name, qty]
        for (let i = 0; i < entries.length; i++) {
            const [name, qty] = entries[i];

            // buscar índice dentro de CARD_DATA
            const cardIndex = runtime.lifeAsDev.DeckCreator.CARD_DATA.findIndex(c => c.name.toLowerCase() === name.toLowerCase());
            if (name === "Guinevere, The Mobility Queen") { 
                console.log(name);
                console.log(cardIndex);
                 }


            if (cardIndex === -1) continue;

            // determinar el tipo de deck según sección
            let deckType = "";
            let isRuler = false;
            switch (sec) {
                case "main":
                    deckType = "deck1";
                    break;

                case "runes":
                    deckType = "rune1";
                    break;

                case "stones":
                    deckType = "stones1";
                    break;

                case "ruler":
                    isRuler = true;
                    break;
            }

            // enviar la cantidad correspondiente
            for (let q = 0; q < qty; q++) {
                if (isRuler) {
                    // rulers se envían a createRuler
                    runtime.callFunction("createRuler", cardIndex);
                } else {
                    runtime.callFunction("sendToDeck", true, cardIndex, deckType, 0);
                }
            }
        }
    }
}

const scriptsInEvents = {

	async EventDeck_Event2_Act3(runtime, localVars)
	{
		runtime.lifeAsDev.DeckCreator =  new DeckCreator([]);
		
		if(runtime.lifeAsDev.cardsData){
		    runtime.lifeAsDev.DeckCreator.CARD_DATA = runtime.lifeAsDev.cardsData;
		}
		
	},

	async EventSheet1_Event6_Act2(runtime, localVars)
	{
		runtime.lifeAsDev.cardsData =  JSON.parse(localVars.ajaxData);
		if(runtime.lifeAsDev.DeckCreator ){
		    runtime.lifeAsDev.DeckCreator.CARD_DATA = runtime.lifeAsDev.cardsData;
		}
		
		
	},

	async EventGame_Event14_Act1(runtime, localVars)
	{
		sendDeckToRuntime(runtime);
	},

	async EventGame_Event174(runtime, localVars)
	{
		const message = {
			type:localVars.type,
			p1:localVars.p1,
			p2:localVars.p2,
			p3:localVars.p3,
			p4:localVars.p4,
			p5:localVars.p5,
		    p6:localVars.p6,
		    p7:localVars.p7
		}
		localVars.message = JSON.stringify(message);
	}
};

globalThis.C3.JavaScriptInEvents = scriptsInEvents;
