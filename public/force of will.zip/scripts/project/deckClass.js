// app.js
class DeckCreator {
    constructor(cardData) {
        this.CARD_DATA = cardData;
        this.deck = { ruler: {}, main: {}, stones: {}, runes: {}, side: {} };
        this.searchInput = document.getElementById('search');
        this.resultsEl = document.getElementById('results');
        this.tpl = document.getElementById('result-item-tpl');
        this.sectionEls = {
            ruler: document.getElementById('ruler-list'),
            main: document.getElementById('main-list'),
            stones: document.getElementById('stones-list'),
            runes: document.getElementById('runes-list'),
            side: document.getElementById('side-list')
        };
        this.init();
    }

    getCardByIndex(index) {
        if (!Array.isArray(this.CARD_DATA)) return null;
        if (index < 0 || index >= this.CARD_DATA.length) return null;

        return this.CARD_DATA[index];
    }

    init() {
        this.bindSearch();
        this.bindTopButtons();
        this.renderAllSections();
        this.loadFromStorage();
    }
    bindSearch() {
        this.searchInput.addEventListener('keydown', e => {
            if (e.key !== 'Enter') return;

            const q = e.target.value.trim().toLowerCase();

            this.renderResults(q);
        });
    }

    renderResults(query) {
        this.resultsEl.innerHTML = '';
        if (!query) return;
        const filtered = this.CARD_DATA.filter(c => c.name.toLowerCase().includes(query));
        for (const card of filtered) {
            const node = this.tpl.content.cloneNode(true);
            const root = node.querySelector('.result-item');
            root.querySelector('.name').textContent = card.name;
            root.querySelector('.meta').textContent = card.id;
            const buttons = root.querySelectorAll('.btn-add');

            buttons.forEach(btn => {
                btn.addEventListener('click', () => {
                    const section = btn.getAttribute('data-section');
                    this.addToSection(section, card.name);
                });
            });

            root.addEventListener('keydown', e => {
                if (e.key === 'Enter') {
                    // default: add to main (or choose another)
                    this.addToSection('main', card.name);
                }
            });
            this.resultsEl.appendChild(node);
        }
    }
    addToSection(section, name) {
        if (!this.deck[section]) return;
        if (!this.deck[section][name]) {
            this.deck[section][name] = 1;
        } else {
            this.deck[section][name]++;
        } this.renderSection(section);
        this.saveToStorage();
    }
    renderSection(section) {
        const el = this.sectionEls[section];
        el.innerHTML = '';

        const entries = Object.entries(this.deck[section]); // [name, count]

        for (const [name, count] of entries) {
            const item = document.createElement('div');
            item.className = 'card-entry';

            const n = document.createElement('div');
            n.className = 'name';
            n.textContent = name + " x" + count;

            const controls = document.createElement('div');
            controls.className = "controls";

            // ---- BUTTON REMOVE (–) ----
            const btnMinus = document.createElement('button');
            btnMinus.textContent = '-';
            btnMinus.addEventListener('click', () => {
                this.deck[section][name]--;

                if (this.deck[section][name] <= 0) {
                    delete this.deck[section][name];
                }

                this.renderSection(section);
                this.saveToStorage();
            });

            // ---- BUTTON ADD (+) ----
            const btnPlus = document.createElement('button');
            btnPlus.textContent = '+';
            btnPlus.addEventListener('click', () => {
                this.deck[section][name]++;
                this.renderSection(section);
                this.saveToStorage();
            });

            controls.appendChild(btnMinus);
            controls.appendChild(btnPlus);

            item.appendChild(n);
            item.appendChild(controls);
            el.appendChild(item);
        }

        const counter = document.querySelector("[data-section='" + section + "'] .count");
        if (counter) {
            const total = entries.reduce((sum, [, c]) => sum + c, 0);
            counter.textContent = total;
        }
    }

    renderAllSections() {
        for (const s of Object.keys(this.deck)) this.renderSection(s);
    }

    bindTopButtons() {
        document.getElementById('btn-clear').addEventListener('click', () => {
            if (confirm('Clear entire deck?')) {
                for (const k of Object.keys(this.deck)) this.deck[k] = {};
                this.renderAllSections();
                this.saveToStorage();
            }
        });
        document.getElementById('btn-export').addEventListener('click', () => {
            const text = this.exportDeckAsText();
            const w = window.open('', '_blank');
            w.document.body.style.whiteSpace = 'pre';
            w.document.body.textContent = text;
        });
        document.getElementById('btn-import').addEventListener('click', () => {
            const text = prompt('Paste deck text (format: SECTION: Card name)');
            if (!text) return;
            this.importDeckFromText(text);
            this.saveToStorage();
            this.renderAllSections();
        });
    }
    exportDeckAsText() {
        let out = [];

        for (const section of Object.keys(this.deck)) {
            const obj = this.deck[section];

            // agrega header tipo: //ruler
            out.push(`//${section}`);

            for (const name of Object.keys(obj)) {
                const qty = obj[name];
                out.push(`${qty} ${name}`);
            }

            out.push(""); // línea en blanco entre secciones
        }

        return out.join("\n");
    }

    importDeckFromText(text) {
        const lines = text.split(/\r?\n/).map(l => l.trim());
        let section = "main";

        for (const l of lines) {
            if (!l) continue;

            // detect section headers like: //ruler, //stones, //runes, //deck
            const header = l.match(/^\/\/\s*(\w+)/i);
            if (header) {
                section = header[1].toLowerCase();

                if (!this.deck[section]) {
                    this.deck[section] = {}; // sigue siendo objeto
                }

                continue;
            }

            // detect lines like: "4 Something Something"
            const m = l.match(/^(\d+)\s+(.+)$/);
            if (m) {
                const qty = parseInt(m[1], 10);
                const name = m[2];
                if (this.CARD_DATA.every(c => !c.name.toLowerCase().includes(name.toLowerCase()))
                ) {
                    console.log(name + " no encontrado");
                    continue
                }
                // suma cantidad dentro del objeto
                if (!this.deck[section][name]) {
                    this.deck[section][name] = 0;
                }

                this.deck[section][name] += qty;

            } else {
                // tarjeta sin cantidad → cantidad = 1
                const name = l;
                if (this.CARD_DATA.every(c => !c.name.toLowerCase().includes(name.toLowerCase()))
                ) { continue }
                if (!this.deck.main[name]) {
                    this.deck.main[name] = 0;
                }

                this.deck.main[name] += 1;
            }
        }
    }


    saveToStorage() {
        try {
            const stringify = JSON.stringify(this.deck);
            localStorage.setItem('deck_v1', stringify);
        } catch { }
    }
    loadFromStorage() {
        try {
            const raw = localStorage.getItem('deck_v1');
            if (!raw) return;

            const obj = JSON.parse(raw);

            for (const k of Object.keys(this.deck)) {
                if (obj[k] && typeof obj[k] === "object") {
                    this.deck[k] = obj[k];
                }
            }

            this.renderAllSections();
        } catch { }
    }

}
export default DeckCreator;
