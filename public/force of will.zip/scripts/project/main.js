runOnStartup(async runtime => {
    runtime.lifeAsDev = {};
});




