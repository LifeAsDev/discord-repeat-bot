"use strict";
var timer_id = -1,
	timer_running = !1;
function startTimer() {
	timer_running ||
		((timer_running = !0), (timer_id = setInterval(tick, 1e3 / 60)));
}
function stopTimer() {
	timer_running &&
		((timer_running = !1), clearInterval(timer_id), (timer_id = -1));
}
function tick() {
	timer_running && self.postMessage("tick");
}
self.addEventListener(
	"message",
	function (t) {
		var i = t.data;
		i && ("start" === i ? startTimer() : "stop" === i && stopTimer());
	},
	!1
);
