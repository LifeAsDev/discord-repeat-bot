"use strict";
{
    const C3 = self.C3;

    C3.Behaviors.FedericoCalchera_TriggerTimer.Type = class TriggerTimerType extends globalThis.ISDKBehaviorTypeBase
    {
        constructor(objectClass)
        {
            super(objectClass);
        }

        Release()
        {
            super.Release();
        }

        OnCreate()
        {}
    };
}