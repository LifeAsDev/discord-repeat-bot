"use strict";
{
    const C3 = globalThis.C3;

    C3.Behaviors.FedericoCalchera_TriggerTimer = class TriggerTimerBehavior extends globalThis.ISDKBehaviorBase
    {
        constructor(opts)
        {
            super(opts);
        }

        Release()
        {
            super.Release();
        }
    };
}