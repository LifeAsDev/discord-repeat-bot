import "./../waker.js";
import "./c3runtime.js";
import "./plugins/Lifeasdev_MultiplayerWebsocketPlusPlugin/c3runtime/main.js";
import "./objRefTable.js";
import "./project/main.js";
import "./project/javaScriptInEvents.js";
